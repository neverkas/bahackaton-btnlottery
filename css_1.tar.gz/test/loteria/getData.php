<?php
include_once 'firebaseConfig.inc.php';
require_once 'firebase/firebaseLib.php';

$firebaseConn = new firebase(FIREBASE_URL, FIREBASE_TOKEN);

//$firebaseConn->set("hackathon", "pepe1");

$response = $firebaseConn->get(date("YmdH"));
if($response==null){
	$response = "El sorteo del ".date("d/m/Y H")." hs aun no ha comenzado";
}
echo $response;
?>