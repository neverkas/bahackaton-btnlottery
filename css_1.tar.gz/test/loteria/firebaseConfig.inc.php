<?php
define("FIREBASE_URL", "https://btclottery.firebaseio.com/");
define("FIREBASE_TOKEN", "eMg8AsU8GTBFwRZXIWu5UDiun91aJBRiKVUP1uzd");
?>