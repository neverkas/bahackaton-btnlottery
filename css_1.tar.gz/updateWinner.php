<?php
require_once "Game.php";

$time = time();
if($time > Game::getLastBlockTime() && $this->game){

}