<?php

require_once "config.php";
require_once "Game.php";
print_r(Game::getWinningNumber());
echo Game::getLastBlockTime();